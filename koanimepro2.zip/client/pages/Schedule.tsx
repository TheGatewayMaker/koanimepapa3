import { Layout } from "../components/Layout";

export default function Schedule() {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-10">
        <h1 className="text-2xl font-bold">Schedule</h1>
        <p className="mt-2 text-foreground/70">Episode schedule coming soon.</p>
      </div>
    </Layout>
  );
}
